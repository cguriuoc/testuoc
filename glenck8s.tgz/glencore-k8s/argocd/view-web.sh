for context in nix-dev  nix-prd eti-prd eti-dev eti2-dev eti2-prd
do
  echo "[$context] Connect to http://$(kubectl --context $context get svc -n argocd argocd-server -o jsonpath="{.status.loadBalancer.ingress[0].ip}") as admin/$(kubectl --context $context -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d)"
done
