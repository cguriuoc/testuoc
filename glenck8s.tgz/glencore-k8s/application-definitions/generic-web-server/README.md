# Generic Web Server

This is a generic web server that can be used to serve static content.
