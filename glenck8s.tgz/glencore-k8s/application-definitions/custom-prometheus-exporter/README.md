Version: v1
name: custom-prometheus-exporter
description: Deploys an image which contains an interactive api to update the automation metrics database
version: 0.0.2
keywords:
  - Github
  - kubernetes
  - postgressql
  - inventory
maintainers:
- name: Carles & Ken
  email: kenneth.modrego@schroders.com
