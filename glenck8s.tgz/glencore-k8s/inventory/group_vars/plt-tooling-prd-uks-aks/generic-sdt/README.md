
# Generic generic-sdt.schroders.com

# Update ingress controller

- Update message
- Disable ArgoCD Autosync
- Update teh applications ingress controller to point to the generic generic-sdt.schroders.com

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ingress-name
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: "https://generic-sdt.schroders.com"
```