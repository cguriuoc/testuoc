![sonarqube-scan](https://github.schroders.com/Schroders/eti-k8s-cd/actions/workflows/sonarqube-scan.yaml/badge.svg?branch=development)
![checkmarx-scan](https://github.schroders.com/Schroders/eti-k8s-cd/actions/workflows/checkmarx-scan.yaml/badge.svg?branch=development)
#### eti-k8s-cd ###

Infrastructure Kubernetes Continuous deployment

# Configure a new cluster

Configure context on your local kubectl to connect ot the new cluster

Get the api server:

```bash
kubectl config view --minify -o jsonpath='{.clusters[0].cluster.server}'
```

Build an inventory in either  inventory/cloud or inventory/onprem, if the port is not 6443 add a variable "api_port" to the api server hostname entry

```ini
[plt-hosting-dev-uks-aks]
plt-hosting-dev-uks-aks-1d1461c7.hcp.uksouth.azmk8s.io api_port=443

[cloud:children]
plt-hosting-dev-uks-aks

[azure:children]
plt-hosting-dev-uks-aks

[dev:children]
plt-hosting-dev-uks-aks
```

How to get the ArgoCD token in Kubernetes, this token is mapped to a service account that has access to create CDR applications in ArgoCD.

```bash
kubectl get -n argocd secret $(kubectl get -n argocd serviceaccount argocd-server -o jsonpath='{.secrets[0].name}') -o jsonpath='{.data.token}' | base64 --decode

```
The above no longer valid. The token you get it from your ./kube/config file , edit the repo vault for more clues

Store the token in the vault under "argocd_kubernetes_token" using the inventory_hostname as key (the below are NOT actual tokens)

```yaml
argocd_kubernetes_token:
  londk8sc01l001: eyJhbGciOiJSUzI1NiIsImtpZCI6Im44cThHMjdxb0tnYkdWSkVXUGxTRktHV3VDZzZ2U1ZZS1JhbHVzNDJwVEUifQ.
  lonpk8sc01l001: eyJhbGciOiJSUzI1NiIsImtpZCI6Ik1XZ3dsZmd6YnJleXlFZ2l6Z3BsNkxtS3hGMlBnRVEweWM0WllfLUU0MVkifQ.
  lonpk8sc02l001: eyJhbGciOiJSUzI1NiIsImtpZCI6IlVReUdUSExWMDdINUtLMnA4YlJwRHUyVVpQNW9GcjVlOU1weHIwYUVweEEifQ.
  plt-hosting-dev-uks-aks-1d1461c7.hcp.uksouth.azmk8s.io:  eyJhbGciOiJSUzI1NiIsImtpZCI6IlZybmlKWXM3N2prb25zUkhVaEpYNXNZNHhHaW5uZ1RvdHQxWlJZUjQ0bUEifQ.
```

## Test deployments from command line

For local execution install the Kubernetes collection (this will be installed in your home directory). Standard deployments through Github Actions will automatically deploy the collection.

```bash
ansible-galaxy collection install --force collections/community-kubernetes-2.0.0.tar.gz
```

```bash
ansible-playbook -i inventory kubernetes-app-deployment.yml --vault-password-file=/etc/vault/.vaultpw -l plt-tooling-dev-uks-aks
ansible-playbook -i inventory kubernetes-app-deployment.yml --vault-password-file=/etc/vault/.vaultpw -l plt-tooling-prd-uks-aks
ansible-playbook -i inventory kubernetes-app-deployment.yml --vault-password-file=/etc/vault/.vaultpw -l plt-tooling-prd-uks-aks -e app=turbo
ansible-playbook -i inventory kubernetes-app-deployment.yml --vault-password-file=/etc/vault/.vaultpw -l plt-tooling-dev-uks-aks -e app=opencost
ansible-playbook -i inventory kubernetes-app-deployment.yml --vault-password-file=/etc/vault/.vaultpw -l plt-eti-dev-uks-aks -e app=awx
ansible-playbook -i inventory kubernetes-app-deployment.yml --vault-password-file=/etc/vault/.vaultpw -l plt-eti-prd-uks-aks -e app=loki
```

Note: you can use app=[partial aap name] to only process a subset of applications.

## Vault

Use Ansible UNIX password to decrypt vault, the password to the vault is also kept as a secret named VAULT in this repository.
The vault contains:

* The tokens for the ArgoCD service accounts in Kubernetes to be able to create new applications.
* Any credentials used in the application configuration in the inventory.

```bash
ansible-vault edit --vault-password-file /etc/vault/.vaultpw vault.yml
```

## debug ArgoCD template errors

```bash
$ kubectl get apps -n argocd azure-alert-rule-scheduler -o 'jsonpath={.spec.source.helm.valuesObject}' | json_yaml  > aar.yaml
$ helm template -f ~/tmp/aar.yaml ./azure-alert-rule-scheduler --debug  --dry-run
```


