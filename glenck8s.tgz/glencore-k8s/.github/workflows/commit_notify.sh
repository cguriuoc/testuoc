#!/bin/bash 
#
# Author: Kenneth Modrego
# 18/10/2017  Pulls a GIT reporsitory to a specific location (GIT repo needs to be configured)
# 21/09/2023 Update to run on Github Runners through a workflow
#

MAIL="GlobalTechnologyIPSEnterpriseTooling@schroders.com"
# MAIL="kenneth.modrego@schroders.com"

REPO=$1

cd $REPO

REPO=$(basename $REPO)
BRANCH=$(git branch)
AUTHOR=$(git log -1 | awk -F'<' '/Author:/ {print $1}' | cut -d' ' -f2- )

git log -p  -1 --color | head -1500 | $(dirname "$(realpath "$0")")/ansi2html.sh | mutt -e 'set content_type=text/html' -s "($AUTHOR) GIT commit to $REPO/$BRANCH" $MAIL
