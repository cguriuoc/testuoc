import os, sys
import yaml, json  # PyYAML is required
from automationmetrics.post_automation_run import PostAutomationRun

def process_defaults(fields):

    input_defaults = os.getenv('INPUT_DEFAULTS', '{}')

    if not input_defaults:
        defaults = json.loads(os.getenv('AUTOMATION_DEFAULTS', '{}'))
    else:
        # Convert the YAML string to a Python dictionary
        defaults = yaml.safe_load(input_defaults)
    if fields.get('token') or defaults:

        if fields.get('token'):
            defaults['token'] = fields.get('token')
        with open(os.getenv('GITHUB_ENV'), 'a') as env_file:
            env_file.write(f"AUTOMATION_DEFAULTS={json.dumps(defaults)}\n")


    if debug:
        print (f"Fetched defaults: \n{json.dumps(defaults, indent=4)}")
    return defaults

def get_inputs():

    global debug
    debug = os.getenv('INPUT_DEBUG', False)

    fields = {
        'status': os.getenv('INPUT_STATUS', ''),
        'automation_id': os.getenv('INPUT_AUTOMATION_ID', ''),
        'runbook_task': os.getenv('INPUT_RUNBOOK_TASK', ''),
        'target': os.getenv('INPUT_TARGET', ''),
        'token': os.getenv('INPUT_TOKEN', ''),
        'run_id': os.getenv('INPUT_RUN_ID', ''),
        'message': os.getenv('INPUT_MESSAGE', ''),
        'ref_url': os.getenv('INPUT_REF_URL', ''),
        'ref_id': os.getenv('INPUT_REF_ID', ''),
        'environment': os.getenv('INPUT_ENVIRONMENT', ''),
        'env': os.getenv('INPUT_ENV', ''),
        'time_saved': os.getenv('INPUT_TIME_SAVED', '')
    }
    if debug:
        print(f"Fields: {json.dumps(fields, indent=4)}")

    fields = {k: v for k, v in fields.items() if v}

    defaults = process_defaults(fields)

    # Input arguments will override defaults
    all_fields = { **defaults, **fields }

    if debug:
        print ("full list of arguments:")
        print (json.dumps(all_fields, indent=4))

    return all_fields, defaults

def main():

    # process all inputs
    all_arguments, defaults = get_inputs()

    am = PostAutomationRun()
    result =  am.post_automation_run(**all_arguments)

    if all_arguments.get('status') == 'started' and result.get('run_id'):
        # Store run_id as a environment variable
        with open(os.getenv('GITHUB_ENV'), 'a') as env_file:
            if debug:
                print(f"Storing run_id: {result['run_id']} on AUTOMATION_DEFAULTS environment variable")
            defaults['run_id'] = result['run_id']
            env_file.write(f"AUTOMATION_DEFAULTS={json.dumps(defaults)}\n")
            if debug:
                print (f"AUTOMATION_DEFAULTS={json.dumps(defaults)}\n")

if __name__ == "__main__":
    main()
