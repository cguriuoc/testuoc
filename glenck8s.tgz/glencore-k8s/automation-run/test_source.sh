export INPUT_DEFAULTS='
  automation_id: 48
  runbook_task: workflow start
  ref_id: "9999"
  ref_url: https://github.schroders.com/Schroders/test/actions/runs/0000
  environment: Production
  target: app1
  time_saved: 0'
export INPUT_STATUS=started
export INPUT_ENV=dev
export GITHUB_ENV=test.env