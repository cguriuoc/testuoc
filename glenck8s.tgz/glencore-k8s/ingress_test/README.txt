#
# There are two DNS A records pointng at both dev and prd clusters :
#
#

test-dev-eti.schroders.com: 10.228.32.99

test-prd-eti.schroders.com: 10.228.34.99

There is only one cert in generic_cert_prd_and_dev which is valid for both url.

###
